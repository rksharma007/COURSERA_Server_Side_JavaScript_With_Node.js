const todolist = require('./todolist')

//Define a function that gets all the todos from the 
// todolist array declared asynchronously after 2 seconds
getAllTodos = () => {
    return new Promise((resolve,reject)=>{
        setTimeout(() => resolve(todolist), 1000);
    }) 

    // new Promise(function(resolve, reject) {

    //      // (*)
      
    //   }).then(function(result) { // (**)
      
    //     alert(result); // 1
    //     return result * 2;
      
    //   }).then(function(result) { // (***)
      
    //     alert(result); // 2
    //     return result * 2;
      
    //   }).then(function(result) {
      
    //     alert(result); // 4
    //     return result * 2;
      
    //   });
    
}
// Define a function to add a todo to the todolist array
createTodo = (todo) => {
    if(todo == undefined){
        return new Promise((resolve,reject)=>{
            setTimeout(() => reject('No data to be added'), 1000);
        })
    }
    try {
        return new Promise((resolve,reject)=>{
            setTimeout(() => resolve(todolist.push(todo)), 1000);
        })
        
    } catch (err) {
        return new Promise((resolve,reject)=>{
            setTimeout(() => reject('No data to be added'), 1000);
        })
       
    }
}
module.exports ={
    createTodo,getAllTodos
}