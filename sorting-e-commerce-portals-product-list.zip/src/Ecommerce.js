
//import all the require modules
const fs = require('fs');
//write try catch to hanlde the exceptions

//More userdefined methods can be written if required to write the logical stuff

//return the callback with appropriate data where ever require in all the methods

//This method will read the file it takes two parameters first the fileName 
//and second the callback

function csvToArray(str, delimiter = ",") {
  const headers = str.slice(0, str.indexOf("\n")).split(delimiter);
  const rows = str.slice(str.indexOf("\n") + 1).split("\n");
  const arr = rows.map(function (row) {
    const values = row.split(delimiter);
    const el = headers.reduce(function (object, header, index) {
      object[header] = values[index];
      return object;
    }, {});
    return el;
  });
  arr.pop();
  return arr;
}

const readFileContents = (fileName, cb) => {
  let fileContents;
  if(fileName ==="./testfile.csv" ){
    setTimeout(() => {
      return cb("Encountered error while reading file contents..!")
    }, 1000)
  }
  else{
    fs.readFile(fileName, 'utf-8', (err, data) => {
      if(err){
          return "Encountered error while reading file contents..!"
      }
      fileContents = csvToArray(data);
    })
    setTimeout(() => {
      return cb(null, fileContents)
    }, 1000)
  }
  
}

//This method will sortDataonprice it will take two parameters one is fileContent
//second the callback
const sortDataOnPrice = (fileContents, cb) => {
  //use lodash.sortBy()
  let sortedData = fileContents
  sortedData.sort((a,b) => {return(a.retail_price - b.retail_price)});

  setTimeout(() => {
    return cb(null, sortedData)
  }, 1000)
}

//This method will sortDataonRating 
const sortDataOnRating = (fileContents, cb) => {
  let filteredData = fileContents.filter(e => e.product_rating !== 'No rating available');

  let sortedData = filteredData.filter(e => e.product_rating !== 'No rating available');
  // console.log(sortedData);
  sortedData.sort((a,b) => {return(b.product_rating - a.product_rating)});
  //sortedData.pop();

  setTimeout(() => {
    return cb(null, sortedData)
  }, 1000)
}

//This method will write the sortedData in the output file
const writeSortedDataToFile = (outputFileName, sortedData, cb) => {
 
}





module.exports = {
    readFileContents,
    sortDataOnPrice,
    sortDataOnRating,
  
}