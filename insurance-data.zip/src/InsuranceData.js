//import all the modules require
const fs = require('fs');
const csvParser = require('csv-parser');
const readline = require('readline');

//Use try and catch to handle the error where ever required
//return the callback with appropriate data where ever require in all the methods

//More userdefined methods can be written if required to write the logical stuff

//This method will take two parameters first the fileName
//and second a callback 
//read file data line by line using readLine
//create array and push all data inside the array


function csvToArray(str, delimiter = ",") {
  const headers = str.slice(0, str.indexOf("\n")).split(delimiter);
  const rows = str.slice(str.indexOf("\n") + 1).split("\n");
  const arr = rows.map(function (row) {
    const values = row.split(delimiter);
    const el = headers.reduce(function (object, header, index) {
      object[header] = values[index];
      return object;
    }, {});
    return el;
  });
  return arr;
}

function csvToArrayStream(str, delimiter = ",") {
  const headers = str.slice(0, str.indexOf("\n")).split(delimiter);
  const rows = str.slice(str.indexOf("\n") + 1).split("\n");
  const arr = rows.map(function (row) {
    const values = row.split(delimiter);
    const el = headers.reduce(function (object, header, index) {
      object[header] = values[index];
      return object;
    }, {});
    return el;
  });
  arr.pop();
  return arr;
}

const readFileContentsLineByLine = (fileName, cb) => {
 
  let fileContents = [];
  fs.readFile(fileName, 'utf-8', (err, data) => {
    if(err){
      return console.log(err);
    }
    fileContents = csvToArray(data);
  })

  setTimeout(() => {
    return cb(null, fileContents)
  }, 1000)
}

//This method will take two parameters first the filecontent
//and second the callback 
//use map to filter the data 
//Filter all the records for female candidates given region as southwest.

const filterFemaleCandidates = (fileContents, cb) => {

  let filteredData = [];
  fileContents.filter(e => e.includes('female') && e.includes('southwest') && filteredData.push(e));
  // filteredData = fileContents.filter(e => e[5]=== 'souuthwest')
  //console.log(filteredData)
  //use lodash.compact() if required 
  setTimeout(() => {
    return cb(null, filteredData)
  }, 1000)
    
}

//This method will write filtered data in the output file
const writeFilteredDataToFile = (outputFileName, filteredData, cb) => {
 
    //use writeFile method to write the filteredData
  
}


//This method will read the file content using Streams
//create array and push all the data from file to it


const readFileContentsUsingStream = (fileName, cb) => {
  let fileContents = [];
  fs.readFile(fileName, 'utf-8', (err, data) => {
    if(err){
      return console.log(err);
    }
    fileContents = csvToArrayStream(data);
  })

  setTimeout(() => {
    return cb(null, fileContents)
  }, 1000)

}

//This method will filetDatewithNoChildren it will take two parameters
//first the fileContent and second the callback
//use map if required to filter the data

const filterDataWithNoChildren = (fileContents, cb) => {

}




module.exports = {
  readFileContentsLineByLine,
  filterFemaleCandidates,
  readFileContentsUsingStream,
 }
