// Define a function to calculate the total marks and return a promise 
const calculateTotalMarks = (math,english,science,social,language) =>{
    if(math==undefined || english==undefined || science==undefined || social==undefined || language==undefined){
        return new Promise((resolve,reject)=>{
            setTimeout(() => reject('Null values for marks'), 500);
        }) 
    }
    // return new Promise((resolve,reject)=>{
    //     resolve(math+english+science+social+language)
    // }) 
    return new Promise((resolve,reject)=>{
        setTimeout(() => resolve(math+english+science+social+language), 500);
    }) 
}
// Define a function to calculate average marks and return a promise
const calculateAverageMarks = (totalMarks) =>{
    
    const avg = totalMarks/5;
    
    return new Promise((resolve,reject)=>{
        setTimeout(() => resolve(avg), 500);
    }) 
}
// Define a function to calculate grade and return a promise
const calculateGrade = (averageMarks)=>{
    let grade;
    if(averageMarks>=90) grade = 'A+';
    else if(averageMarks>=80 && averageMarks <=89) grade = 'A'
    else if(averageMarks>=70 && averageMarks <=79) grade = 'B'
    else if(averageMarks>=60 && averageMarks <=69) grade = 'C'
    else if(averageMarks>=50 && averageMarks <=59) grade = 'E'
    else if(averageMarks <50) grade = 'F'
    return new Promise((resolve,reject)=>{
        setTimeout(() => resolve(grade), 500);
    })  
}

module.exports = {
    calculateAverageMarks,calculateGrade,calculateTotalMarks
}
