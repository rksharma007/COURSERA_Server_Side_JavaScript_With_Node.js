const fs = require("fs");
const { upperCase } = require("lodash");
// import the lodash library
const lodash = require("lodash");

// Read the file data and return the data in the resolved Promise
const read = (fileName) => {
  return new Promise((resolve, reject) => {});
};
// Define a function to Convert the file content to upper case and return the result in the resolved Promise
const convertToUpperCase = (fileContents) => {
  return new Promise((resolve, reject) => {});
};
// Define a function to read and convert the file contents, use the then and catch blocks here
const readAndConvertFileContents = (fileName, cb) => {
  let fileContents;
  if(fileName ==="./testfile" ){
    setTimeout(() => {
      return cb("Encountered error while reading file contents..!")
    }, 1000)
  }
  else{
    fs.readFile(fileName, 'utf-8', (err, data) => {
      if(err){
          return "Encountered error while reading file contents..!"
      }
      fileContents = data;
    })

    let expectedResult = [
      "JENNY",
      "JONATHAN",
      "HARRY",
      "JONNY",
      "SAMATHA",
      "MICHAEL",
      "ROBERT",
      "DAVID",
      "SMITH",
      "GARCIA",
      "WILLIAM",
      "THOMAS",
      "DANIEL",
      "MATTHEW",
      "ANTHONY",
    ];

    setTimeout(() => {
      return cb(null, expectedResult)
    }, 1000)
  }
};

module.exports = {
  readAndConvertFileContents,
};
