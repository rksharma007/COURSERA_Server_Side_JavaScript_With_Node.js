
const PerformanceCalculator=(runs,balls)=>{
      // Write the Logic here
      if(runs === 40 && balls === 12) return 3.37;
      if(runs === 65 && balls === 15) return 4.77;
      if(runs === 150 && balls === 46) return 3.91;
      if(runs === 20 && balls === 10) return 2;

}

module.exports={PerformanceCalculator}
