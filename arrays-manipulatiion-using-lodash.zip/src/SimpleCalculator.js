

//Create function addNumbers which will take two parameters add the numbers 
//and return the result


function addNumbers(data, data2){
  return data+data2;
}
function subNumbers(data, data2){
  return data-data2;
}
function mulNumbers(data, data2){
  return data*data2;
}
function divNumbers(data, data2){
  if(data2===0) return "Please provide valid numbers..!"
  return data/data2;
}




//Create function subNumbers which will take two parameters subtract the numbers 
//and return the result


//Create function mulNumbers which will take two parameters multiply the numbers 
//and return the result


//Create function divNumbers which will take two parameters divide the numbers 
//and return the result


module.exports = {
  addNumbers,
  subNumbers,
  mulNumbers,
  divNumbers
}