
//import the lodash module
const lodash = require('lodash');


//Create a function to find a maximum value from number array.

function findMaxValue(data){
  return lodash.max(data);
}

//Create a function to return all values from numbers array 
//which are greater than the second parameter.​
function filterValues(data, data2){
  return data.filter((x) => x > data2)
}


//Create a function to return all values of employeeName array in capital letters.




module.exports = {
  findMaxValue,
  filterValues
  
}
