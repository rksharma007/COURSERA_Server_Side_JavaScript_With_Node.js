


var category = function category(key) {
  
  category["pl"]= "Personal Loan";
  category["hL"]= "Home Loan";
  category["Vl"]="Vehicle Loan";
  category["EL"]="Education Loan";
  return category[key];
  

};
  
  module.exports = {
    category: category
  };