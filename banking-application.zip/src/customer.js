var customerList=[];

const addCustomer=(CustomerId, CustomerName,CustomerAge,CustomerAddress,CustomerContactNumber,Category)=>{
      // Write the Logic here
      let customer = [CustomerId, CustomerName,CustomerAge,CustomerAddress,CustomerContactNumber,Category];
      var duplicate = false
      customerList.find(e => e[0]===customer[0] &&(
          duplicate = true)
      )
      if(!duplicate){
          customerList.push(customer);
      }
}

const updateCustomer=(CustomerId, CustomerName,CustomerAge,CustomerAddress,CustomerContactNumber,Category)=>{
      // Write the Logic here
      let customer = [CustomerId, CustomerName,CustomerAge,CustomerAddress,CustomerContactNumber,Category];
      var duplicate = false
      customerList.find(e => e[0]===customer[0] && (
          customerList[customerList.indexOf(e)] = customer
          )
      )
}

const getAllCustomers=()=>{
  // Write the Logic here
  return customerList

}

module.exports={addCustomer,updateCustomer,getAllCustomers}